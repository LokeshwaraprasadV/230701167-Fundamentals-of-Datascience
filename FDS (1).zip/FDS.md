```python
import pandas as pd
import matplotlib.pyplot as plt 

data = {'Year': list(range(2010, 2021)), 'Job Posting': [150, 300, 450, 600, 800, 1200, 1600, 2100, 3400, 4200,6000]}
df = pd.DataFrame(data)

plt.plot(df['Year'], df['Job Posting'], marker='o')
plt.title("TREND OF DATA SCIENCE JOB POSTINGS")
plt.xlabel('Year')
plt.ylabel('Number of Job Postings')
plt.show()
```


    
![png](output_0_0.png)
    



```python

```
